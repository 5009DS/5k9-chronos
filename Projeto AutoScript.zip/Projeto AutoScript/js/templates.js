// --- Predefined Script Templates for AutoScript ---

const SCRIPT_TEMPLATES = {
  blank: {
    title: "Novo Roteiro",
    format: "Reel",
    targetDuration: 30,
    concept: "",
    tone: "",
    acts: {
      setup: "",
      confront: "",
      resolve: ""
    },
    characters: ["NARRADOR"],
    scenes: [
      {
        id: "scene_1",
        title: "INT. SALA DE ESTAR - DIA",
        shots: [
          {
            id: "shot_1_1",
            index: "1-1",
            video: "PLANO MÉDIO. O protagonista entra na sala segurando uma caneca.",
            audio: "BG: Trilha sonora leve e inspiradora de fundo.\n\nNARRADOR\nVocê já sentiu que seu dia precisa de mais foco?"
          }
        ]
      }
    ]
  },
  
  abducao: {
    title: "Abdução (Suspense)",
    format: "Reel",
    targetDuration: 30,
    concept: "Um jovem acorda no meio da noite com barulhos e luzes estranhas em seu quarto, culminando em um evento inexplicável.",
    tone: "Tenso, cinematográfico, cortes rápidos, iluminação contrastante com tons de azul e sombra.",
    acts: {
      setup: "Paulo acorda assustado em seu quarto no meio da noite por conta de um despertador tocando. Ele percebe que recebeu uma mensagem de seu amigo João alertando sobre algo estranho.",
      confront: "Paulo atende a ligação de João, mas ouve apenas estática sônica e ruídos metálicos. De repente, os objetos no quarto perdem a gravidade e começam a flutuar.",
      resolve: "Uma luz azul neon intensa entra pela janela. Paulo é erguido no ar em direção ao feixe de luz. A tela apaga com o barulho do celular caindo no chão."
    },
    characters: ["PAULO", "JOÃO", "EFEITO"],
    scenes: [
      {
        id: "scene_1",
        title: "INT. QUARTO DE PAULO - NOITE",
        shots: [
          {
            id: "shot_1_1",
            index: "1-1",
            video: "CLOSE-UP - PLONGÉE - ZOOM-IN.\n\nPaulo acorda assustado e olha ao redor.",
            audio: "BG: Trilha de música de rádio antiga tocando bem baixo ao longe.\n\nFolley: Barulho das roupas de cama se movendo, som de vento soprando lá fora."
          },
          {
            id: "shot_1_2",
            index: "1-2",
            video: "PLANO DETALHE - ZENITAL - DOLLY OUT.\n\nO celular na cabeceira está piscando. A tela se ilumina mostrando 'Chamada de JOÃO' com uma foto engraçada de perfil.",
            audio: "BG: Música distante continua.\n\nFolley: Toque insistente e agudo do despertador/celular."
          },
          {
            id: "shot_1_3",
            index: "1-3",
            video: "PLANO MÉDIO - FRONTAL - DOLLY IN.\n\nPaulo pega o celular e atende, com expressão confusa.",
            audio: "PAULO\n(voz sonolenta)\nAlô? João? Cara, são três da manhã. O que houve?"
          },
          {
            id: "shot_1_4",
            index: "1-4",
            video: "PLANO CONJUNTO - CÂMERA HOLANDESA.\n\nA ligação começa a chiar. A luz do abajur pisca intensamente. O copo de água na mesa flutua 10 centímetros.",
            audio: "BG: Ruído de estática e interferência eletromagnética crescendo.\n\nJOÃO\n(através do celular, com muita estática)\nPaulo! Não olhe para a... [chiado]... eles estão... [estática]."
          }
        ]
      },
      {
        id: "scene_2",
        title: "INT. QUARTO DE PAULO - CONTINUAÇÃO",
        shots: [
          {
            id: "shot_2_1",
            index: "2-1",
            video: "PLANO GERAL.\n\nUma luz azul neon extremamente forte invade o quarto pela janela. Sombras longas são projetadas na parede contrária.",
            audio: "BG: Um som grave e contínuo de sintetizador (drone de suspense) vibra o ambiente."
          },
          {
            id: "shot_2_2",
            index: "2-2",
            video: "PLANO MÉDIO ABERTO.\n\nPaulo começa a levitar lentamente acima da cama, olhando a janela aterrorizado. Seus braços flutuam sem controle.",
            audio: "PAULO\n(gritando)\nSocorro! O que é isso?!"
          },
          {
            id: "shot_2_3",
            index: "2-3",
            video: "FADE OUT RÁPIDO.\n\nA tela fica preta.",
            audio: "Folley: Som do celular batendo no chão seco, seguido por um silêncio absoluto repentino."
          }
        ]
      }
    ]
  },

  marketing: {
    title: "Vídeo de Vendas (TikTok)",
    format: "Reel",
    targetDuration: 60,
    concept: "Vídeo dinâmico em formato vertical para reter usuários nos primeiros 3 segundos e oferecer uma planilha financeira gratuita.",
    tone: "Rápido, enérgico, direto ao ponto, legendas grandes na tela, música empolgante.",
    acts: {
      setup: "Gancho (Hook) ultra rápido: Mostrar um monte de contas acumuladas e fazer a pergunta direta: 'Você sabe para onde vai seu dinheiro todo mês?'.",
      confront: "Desenvolver a frustração de tentar fazer planilhas complexas que demoram horas para configurar e que todo mundo acaba abandonando no terceiro dia.",
      resolve: "Apresentar a solução: a ferramenta AutoFinanças que faz tudo automático por WhatsApp. Terminar com a chamada para ação (CTA) para comentar 'QUERO' para receber o link direto."
    },
    characters: ["APRESENTADOR", "LOCUTOR"],
    scenes: [
      {
        id: "scene_1",
        title: "INT. ESCRITÓRIO - DIA",
        shots: [
          {
            id: "shot_1_1",
            index: "1-1",
            video: "PLANO MÉDIO FECHADO (Câmera Vertical).\n\nO apresentador bate a mão na mesa cheia de boletos, olhando sério para a câmera. Zoom rápido digital (punch-in).",
            audio: "BG: Batida de Hip-Hop instrumental energética inicia.\n\nAPRESENTADOR\nPare de perder dinheiro por não saber onde gasta!"
          },
          {
            id: "shot_1_2",
            index: "1-2",
            video: "PLANO DETALHE.\n\nApresentador deslizando o dedo no celular mostrando uma tabela colorida cheia de gráficos automáticos brilhando.",
            audio: "APRESENTADOR\nSe você odeia aquelas planilhas de Excel cheias de fórmulas que ninguém entende, olha isso aqui."
          },
          {
            id: "shot_1_3",
            index: "1-3",
            video: "GRAVAÇÃO DE TELA (B-Roll).\n\nMostra o usuário mandando uma mensagem de texto simples no WhatsApp: 'Comprei um café por R$ 7'. E o bot responde com um gráfico atualizado em 1 segundo.",
            audio: "APRESENTADOR\nVocê só manda um zap falando quanto gastou, e seu controle financeiro se monta sozinho."
          },
          {
            id: "shot_1_4",
            index: "1-4",
            video: "PLANO MÉDIO FECHADO.\n\nO apresentador aponta para baixo, sorrindo de forma amigável.",
            audio: "APRESENTADOR\nQuer testar de graça? Comenta 'EU QUERO' aqui embaixo que eu te envio o link de acesso exclusivo agora mesmo!"
          }
        ]
      }
    ]
  },

  vlog: {
    title: "Review de Gadget (YouTube)",
    format: "YouTube",
    targetDuration: 180,
    concept: "Introdução para um vídeo de análise de um microfone de lapela sem fio ultra-barato que promete qualidade de estúdio.",
    tone: "Profissional, acolhedor, educativo, com cortes sincronizados com a música.",
    acts: {
      setup: "Comparar a diferença drástica entre o áudio horrível direto da câmera do celular e o áudio limpo do microfone novo.",
      confront: "Mostrar os pontos negativos de microfones profissionais de R$ 2000 que impedem criadores iniciantes de começar devido ao alto custo.",
      resolve: "Revelar o preço desse microfone de R$ 150 e garantir se realmente vale a pena comprar para produzir vídeos profissionais."
    },
    characters: ["APRESENTADOR"],
    scenes: [
      {
        id: "scene_1",
        title: "INT. SALA DE ESTÚDIO - DIA",
        shots: [
          {
            id: "shot_1_1",
            index: "1-1",
            video: "PLANO MÉDIO (Horizontal).\n\nApresentador fala em um cenário bonito com luz de fundo azul e laranja, mas o áudio soa distante e com eco de sala vazia.",
            audio: "APRESENTADOR\nGravar vídeos com o áudio direto do celular pode simplesmente destruir o engajamento do seu canal."
          },
          {
            id: "shot_1_2",
            index: "1-2",
            video: "PLANO DETALHE.\n\nApresentador aperta o clipe do microfone de lapela pequeno em sua camiseta. O áudio muda instantaneamente para uma voz cristalina, encorpada e sem ruído.",
            audio: "Folley: Som estalado do clipe prendendo no tecido.\n\nAPRESENTADOR\n(áudio agora perfeito)\nMas e se eu te disser que você não precisa gastar milhares de reais para ter áudio de estúdio?"
          },
          {
            id: "shot_1_3",
            index: "1-3",
            video: "PLANO DETALHE / B-ROLL.\n\nCâmera desliza sobre a caixinha de carregamento do microfone mostrando os LEDs indicadores acesos em verde.",
            audio: "BG: Música lo-fi relaxante começa no fundo.\n\nAPRESENTADOR\nHoje nós vamos testar o Lapela Pro, que custa menos de duzentos reais na internet. Será que ele presta?"
          }
        ]
      }
    ]
  }
};
