// --- AutoScript Central Application Bootstrap & State Controller ---

const App = {
  projects: [],
  activeProject: null,
  activeTab: "tab-roteiro",
  selectedTemplate: "blank",

  init() {
    this.loadTheme();
    this.loadState();
    
    // If no projects exist, bootstrap with the default 'abducao' template as a demo
    if (this.projects.length === 0) {
      this.bootstrapInitialDemo();
    } else {
      this.activeProject = this.projects[0];
    }

    this.renderSidebar();
    this.loadActiveProject();

    this.bindEvents();
    showToast("AutoScript Carregado!", "success");
  },

  bootstrapInitialDemo() {
    // Clone abducao template
    const demo = JSON.parse(JSON.stringify(SCRIPT_TEMPLATES.abducao));
    demo.id = "proj_" + Date.now();
    demo.dateModified = Date.now();
    
    this.projects.push(demo);
    this.activeProject = demo;
    this.saveState();
  },

  loadState() {
    try {
      const data = localStorage.getItem("autoscript_projects");
      if (data) {
        this.projects = JSON.parse(data);
      }
    } catch (e) {
      console.error("Erro ao carregar do LocalStorage", e);
    }
  },

  saveState() {
    try {
      localStorage.setItem("autoscript_projects", JSON.stringify(this.projects));
    } catch (e) {
      console.error("Erro ao salvar no LocalStorage", e);
    }
  },

  loadActiveProject() {
    if (!this.activeProject) return;

    // Set Header details
    document.getElementById("project-title-input").value = this.activeProject.title;
    document.getElementById("meta-piece-type").value = this.activeProject.format || "Reel";
    document.getElementById("meta-target-duration").value = this.activeProject.targetDuration || 30;

    // Load tabs
    ScreenplayController.init(this.activeProject, () => this.onProjectEdited());
    ScriptEditor.init(this.activeProject, () => this.onProjectEdited());
  },

  onProjectEdited() {
    this.activeProject.dateModified = Date.now();
    this.saveState();
    
    // Update sidebar list if title changed
    const activeItem = document.querySelector(".project-item.active .project-item-title");
    if (activeItem && activeItem.innerText !== this.activeProject.title) {
      activeItem.innerText = this.activeProject.title;
    }
  },

  renderSidebar() {
    const list = document.getElementById("project-list");
    list.innerHTML = "";

    this.projects.forEach((proj) => {
      const li = document.createElement("li");
      li.className = "project-item" + (this.activeProject && this.activeProject.id === proj.id ? " active" : "");
      li.setAttribute("data-proj-id", proj.id);
      
      li.innerHTML = `
        <span class="project-item-title">${proj.title}</span>
        <button class="btn-delete-project" data-proj-id="${proj.id}" title="Excluir Roteiro">
          <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
        </button>
      `;

      // Select Project
      li.onclick = (e) => {
        if (e.target.closest(".btn-delete-project")) return; // Avoid triggering select when deleting
        const id = li.getAttribute("data-proj-id");
        this.selectProject(id);
      };

      // Delete Project
      li.querySelector(".btn-delete-project").onclick = (e) => {
        e.stopPropagation();
        const id = e.currentTarget.getAttribute("data-proj-id");
        this.deleteProject(id);
      };

      list.appendChild(li);
    });
  },

  selectProject(id) {
    const proj = this.projects.find(p => p.id === id);
    if (proj) {
      this.activeProject = proj;
      this.loadActiveProject();
      this.renderSidebar();
      showToast(`Roteiro "${proj.title}" carregado!`, "success");
      
      // Close mobile sidebar if open
      document.getElementById("app-sidebar")?.classList.remove("open");
      document.getElementById("sidebar-overlay")?.classList.remove("open");
    }
  },

  deleteProject(id) {
    if (this.projects.length <= 1) {
      showToast("Você precisa manter pelo menos um roteiro!", "error");
      return;
    }

    const proj = this.projects.find(p => p.id === id);
    if (!proj) return;

    if (confirm(`Tem certeza que deseja excluir o roteiro "${proj.title}" permanentemente?`)) {
      const idx = this.projects.indexOf(proj);
      this.projects.splice(idx, 1);
      
      if (this.activeProject.id === id) {
        this.activeProject = this.projects[0];
      }

      this.saveState();
      this.renderSidebar();
      this.loadActiveProject();
      showToast("Roteiro excluído!", "success");
    }
  },

  bindEvents() {
    // 0. Mobile Sidebar Toggle
    const btnMobileMenu = document.getElementById("btn-mobile-menu");
    const appSidebar = document.getElementById("app-sidebar");
    const sidebarOverlay = document.getElementById("sidebar-overlay");

    const toggleSidebar = () => {
      appSidebar.classList.toggle("open");
      sidebarOverlay.classList.toggle("open");
    };

    if (btnMobileMenu) btnMobileMenu.onclick = toggleSidebar;
    if (sidebarOverlay) sidebarOverlay.onclick = toggleSidebar;

    // 1. Project Title renaming
    const titleInput = document.getElementById("project-title-input");
    titleInput.onblur = (e) => {
      let val = e.target.value.trim();
      if (!val) val = "Roteiro Sem Título";
      this.activeProject.title = val;
      e.target.value = val;
      this.onProjectEdited();
    };

    titleInput.onkeydown = (e) => {
      if (e.key === "Enter") {
        titleInput.blur();
      }
    };

    // 2. Metadata changes
    document.getElementById("meta-piece-type").onchange = (e) => {
      this.activeProject.format = e.target.value;
      this.onProjectEdited();
    };

    document.getElementById("meta-target-duration").oninput = (e) => {
      this.activeProject.targetDuration = parseInt(e.target.value) || 30;
      this.onProjectEdited();
      ScriptEditor.calculateDuration();
    };

    // 3. Tab switching
    const tabBtns = document.querySelectorAll(".tab-btn");
    tabBtns.forEach(btn => {
      btn.onclick = () => {
        tabBtns.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        
        const targetTab = btn.getAttribute("data-tab");
        document.querySelectorAll(".tab-pane").forEach(p => p.classList.remove("active-pane"));
        document.getElementById(targetTab).classList.add("active-pane");
        
        this.activeTab = targetTab;

        // Force full refresh of script technical grid layout on switch
        if (targetTab === "tab-script") {
          ScriptEditor.render();
        } else if (targetTab === "tab-roteiro") {
          ScreenplayController.init(this.activeProject, () => this.onProjectEdited());
        }
      };
    });

    // 4. Modals and Creation
    const newProjectBtn = document.getElementById("btn-new-project");
    const closeNewProjectBtn = document.getElementById("btn-close-new-project");
    const cancelProjectBtn = document.getElementById("btn-cancel-project");
    const submitProjectBtn = document.getElementById("btn-create-project-submit");
    const modalNewProject = document.getElementById("modal-new-project");

    newProjectBtn.onclick = () => {
      document.getElementById("new-project-title").value = "Novo Roteiro";
      modalNewProject.classList.add("open");
      
      // Close mobile sidebar if open
      document.getElementById("app-sidebar")?.classList.remove("open");
      document.getElementById("sidebar-overlay")?.classList.remove("open");
    };

    const closeModal = () => {
      modalNewProject.classList.remove("open");
    };

    closeNewProjectBtn.onclick = closeModal;
    cancelProjectBtn.onclick = closeModal;

    // Handle template card clicks inside Modal
    const tempCards = document.querySelectorAll(".template-option");
    tempCards.forEach(card => {
      card.onclick = () => {
        tempCards.forEach(c => c.classList.remove("active"));
        card.classList.add("active");
        this.selectedTemplate = card.getAttribute("data-template");
      };
    });

    submitProjectBtn.onclick = () => {
      const title = document.getElementById("new-project-title").value.trim() || "Roteiro Sem Título";
      const format = document.getElementById("new-project-format").value;

      // Prepare project model based on template selection
      const templateSrc = SCRIPT_TEMPLATES[this.selectedTemplate] || SCRIPT_TEMPLATES.blank;
      
      const newProj = JSON.parse(JSON.stringify(templateSrc));
      newProj.id = "proj_" + Date.now();
      newProj.title = title;
      newProj.format = format;
      newProj.dateModified = Date.now();

      this.projects.push(newProj);
      this.activeProject = newProj;
      this.saveState();
      
      closeModal();
      this.renderSidebar();
      this.loadActiveProject();
      
      // Auto transition to the script editor tab to show the structure
      document.querySelector(".tab-btn[data-tab='tab-script']").click();
      showToast(`Roteiro "${title}" criado com sucesso!`, "success");
    };

    // 5. Technical Grid Toolbar buttons
    document.getElementById("btn-add-scene").onclick = () => {
      ScriptEditor.addScene();
    };

    document.getElementById("btn-add-shot").onclick = () => {
      if (this.activeProject.scenes && this.activeProject.scenes.length > 0) {
        const lastSceneId = this.activeProject.scenes[this.activeProject.scenes.length - 1].id;
        ScriptEditor.addShot(lastSceneId);
      } else {
        ScriptEditor.addScene();
      }
    };

    document.getElementById("btn-create-first-row").onclick = () => {
      ScriptEditor.addScene();
    };

    // 6. Theme Switching
    const themeBtn = document.getElementById("theme-toggle");
    themeBtn.onclick = () => {
      const htmlClass = document.documentElement.classList;
      if (htmlClass.contains("dark-theme")) {
        htmlClass.remove("dark-theme");
        htmlClass.add("light-theme");
        localStorage.setItem("autoscript_theme", "light");
        themeBtn.querySelector(".toggle-text").innerText = "Tema Escuro";
      } else {
        htmlClass.remove("light-theme");
        htmlClass.add("dark-theme");
        localStorage.setItem("autoscript_theme", "dark");
        themeBtn.querySelector(".toggle-text").innerText = "Tema Claro";
      }
    };

    // 7. Exports bindings
    document.getElementById("btn-export-pdf").onclick = () => {
      Exporter.printPDF(this.activeProject, this.activeTab);
    };

    // Dropdown toggle
    const dropBtn = document.getElementById("btn-export-options");
    dropBtn.onclick = (e) => {
      e.stopPropagation();
      dropBtn.parentElement.classList.toggle("open");
    };

    window.addEventListener("click", () => {
      document.querySelectorAll(".dropdown").forEach(d => d.classList.remove("open"));
    });

    document.getElementById("export-csv").onclick = (e) => {
      e.preventDefault();
      Exporter.exportToCSV(this.activeProject);
    };

    document.getElementById("export-json").onclick = (e) => {
      e.preventDefault();
      Exporter.exportToJSON(this.activeProject);
    };

    // 8. Import JSON file listener
    const importInput = document.getElementById("import-json");
    importInput.onchange = (e) => {
      if (e.target.files.length > 0) {
        Exporter.importFromJSON(e.target.files[0], (importedProj) => {
          importedProj.id = "proj_" + Date.now();
          importedProj.dateModified = Date.now();
          
          this.projects.push(importedProj);
          this.activeProject = importedProj;
          this.saveState();
          this.renderSidebar();
          this.loadActiveProject();
        });
        // Clear file input
        importInput.value = "";
      }
    };
  },

  loadTheme() {
    const saved = localStorage.getItem("autoscript_theme") || "dark";
    const themeBtn = document.getElementById("theme-toggle");
    if (saved === "light") {
      document.documentElement.className = "light-theme";
      if (themeBtn) themeBtn.querySelector(".toggle-text").innerText = "Tema Escuro";
    } else {
      document.documentElement.className = "dark-theme";
      if (themeBtn) themeBtn.querySelector(".toggle-text").innerText = "Tema Claro";
    }
  }
};

// --- General Toast Notification system ---
function showToast(message, type = "success") {
  const container = document.getElementById("toast-container");
  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <span>${message}</span>
    <span style="margin-left: 12px; opacity: 0.6; cursor: pointer;">✕</span>
  `;

  // Manual dismiss
  toast.querySelector("span:last-child").onclick = () => {
    toast.remove();
  };

  container.appendChild(toast);

  // Auto disappear after 3 seconds
  setTimeout(() => {
    toast.style.animation = "fade-out 0.25s forwards";
    setTimeout(() => toast.remove(), 250);
  }, 3000);
}

// Start application
window.onload = () => {
  App.init();
};
