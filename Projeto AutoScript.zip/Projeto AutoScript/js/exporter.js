// --- Exporter Utility for AutoScript ---

const Exporter = {
  // Export current script to CSV format (compatible with Excel and Google Sheets)
  exportToCSV(project) {
    if (!project || !project.scenes) {
      showToast("Nenhum dado de script para exportar!", "error");
      return;
    }

    let csvContent = "\ufeff"; // BOM for UTF-8 compatibility with Excel
    
    // Title header info
    csvContent += `Roteiro:;"${project.title.replace(/"/g, '""')}"\n`;
    csvContent += `Formato:;"${project.format}"\n`;
    csvContent += `Duração Estimada:;"${project.estimatedDuration || 0}s"\n\n`;
    
    // Column Headers
    csvContent += "Cena/Tomada;Vídeo (Imagem e Ações);Áudio (Diálogo e Sons)\n";
    
    project.scenes.forEach((scene) => {
      // Add Scene Heading row
      csvContent += `"${scene.title.replace(/"/g, '""')}";"";""\n`;
      
      scene.shots.forEach((shot) => {
        // Prepare contents, stripping potential HTML tags from contenteditable cells
        const cleanVideo = this.stripHTML(shot.video).replace(/"/g, '""');
        const cleanAudio = this.stripHTML(shot.audio).replace(/"/g, '""');
        csvContent += `"${shot.index}";"${cleanVideo}";"${cleanAudio}"\n`;
      });
    });

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    
    const safeTitle = project.title.toLowerCase().replace(/[^a-z0-9]/g, "_");
    link.setAttribute("href", url);
    link.setAttribute("download", `autoscript_${safeTitle}.csv`);
    link.style.visibility = "hidden";
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    showToast("Planilha CSV exportada com sucesso!", "success");
  },

  // Export full project JSON for backup/import purposes
  exportToJSON(project) {
    if (!project) return;
    
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(project, null, 2));
    const downloadAnchor = document.createElement("a");
    
    const safeTitle = project.title.toLowerCase().replace(/[^a-z0-9]/g, "_");
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `autoscript_${safeTitle}.json`);
    downloadAnchor.style.visibility = "hidden";
    
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    document.body.removeChild(downloadAnchor);
    
    showToast("Arquivo JSON exportado para backup!", "success");
  },

  // Import project JSON
  importFromJSON(file, callback) {
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const importedProject = JSON.parse(event.target.result);
        
        // Basic schema validation
        if (!importedProject.title || !importedProject.scenes || !Array.isArray(importedProject.scenes)) {
          showToast("Formato de arquivo inválido!", "error");
          return;
        }
        
        callback(importedProject);
        showToast("Projeto importado com sucesso!", "success");
      } catch (err) {
        showToast("Erro ao ler o arquivo JSON!", "error");
        console.error(err);
      }
    };
    reader.readAsText(file);
  },

  // Prepares printable elements and triggers window.print()
  printPDF(project, activeTab) {
    if (!project) return;

    // Set document title temporarily so browser prints it as the PDF name
    const originalTitle = document.title;
    document.title = `AutoScript - ${project.title}`;
    
    // Add print mode class based on activeTab
    document.body.classList.remove("print-mode-roteiro", "print-mode-script");
    
    const today = new Date();
    const formattedDate = today.toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric"
    });

    if (activeTab === "tab-roteiro") {
      document.body.classList.add("print-mode-roteiro");
      
      // Populate Roteiro print nodes
      document.getElementById("print-rot-title").innerText = project.title;
      document.getElementById("print-rot-meta-type").innerText = project.format || "Reel";
      document.getElementById("print-rot-meta-target").innerText = `${project.targetDuration || 30}s`;
      document.getElementById("print-rot-meta-date").innerText = formattedDate;
      
      // Elements content
      document.getElementById("print-rot-concept").innerText = project.concept || "Sem conceito definido.";
      document.getElementById("print-rot-tone").innerText = project.tone || "Sem estilo definido.";
      document.getElementById("print-rot-chars").innerText = (project.characters && project.characters.length > 0) 
        ? project.characters.join(", ") 
        : "Nenhum personagem cadastrado.";
        
      document.getElementById("print-rot-act1").innerText = project.acts.setup || "Sem conteúdo.";
      document.getElementById("print-rot-act2").innerText = project.acts.confront || "Sem conteúdo.";
      document.getElementById("print-rot-act3").innerText = project.acts.resolve || "Sem conteúdo.";
    } else {
      document.body.classList.add("print-mode-script");
      
      // Update the print-only header elements in the HTML for technical script
      document.getElementById("print-project-title").innerText = project.title;
      document.getElementById("print-meta-type").innerText = project.format || "Reel";
      document.getElementById("print-meta-duration").innerText = `${project.estimatedDuration || 0}s`;
      document.getElementById("print-meta-date").innerText = formattedDate;
    }

    // Trigger print
    window.print();

    // Restore page title after print dialog closes
    setTimeout(() => {
      document.title = originalTitle;
      document.body.classList.remove("print-mode-roteiro", "print-mode-script");
    }, 1000);
  },

  // Helper utility to remove HTML tag markers and decode entities
  stripHTML(htmlString) {
    const tempDiv = document.createElement("div");
    tempDiv.innerHTML = htmlString;
    return tempDiv.textContent || tempDiv.innerText || "";
  }
};
