// --- Dual Column Technical Script Editor ---

const ScriptEditor = {
  activeProject: null,
  onSaveCallback: null,
  activeCell: null,
  
  // Camera & Video Autocomplete options
  videoSuggestions: [
    "CLOSE", "PLANO DETALHE", "PLANO MÉDIO", "PLANO GERAL", 
    "PLONGÉE", "ZENITAL", "ZOOM-IN", "ZOOM-OUT", "DOLLY IN", 
    "DOLLY OUT", "CÂMERA HOLANDESA", "PANORÂMICA", "FRONTAL",
    "REVELAÇÃO", "FADE IN", "FADE OUT"
  ],

  // Audio cues Autocomplete options
  audioSuggestions: [
    "BG: trilha de música ", "BG: trilha de suspense", "BG: silêncio", 
    "Folley: barulho de ", "Folley: passos", "Folley: vento",
    "Loc. 01: voz narrativa", "NARRADOR"
  ],

  init(project, onSave) {
    this.activeProject = project;
    this.onSaveCallback = onSave;
    
    this.render();
    this.bindGlobalEvents();
  },

  render() {
    const container = document.getElementById("script-grid-body");
    const emptyState = document.getElementById("script-empty-state");
    container.innerHTML = "";

    if (!this.activeProject.scenes || this.activeProject.scenes.length === 0) {
      container.parentElement.style.display = "none";
      emptyState.style.display = "flex";
      this.calculateDuration();
      return;
    }

    container.parentElement.style.display = "flex";
    emptyState.style.display = "none";

    // Loop through scenes
    this.activeProject.scenes.forEach((scene, sceneIdx) => {
      // 1. Render Scene Heading Row
      const sceneRow = document.createElement("div");
      sceneRow.className = "scene-heading-row no-print";
      sceneRow.innerHTML = `
        <div class="scene-heading-index">Cena ${String(sceneIdx + 1).padStart(2, '0')}</div>
        <div class="scene-heading-content" contenteditable="true" 
             placeholder="CABEÇALHO DE CENA (Ex: INT. QUARTO DE PAULO - NOITE)" 
             data-scene-id="${scene.id}">${scene.title}</div>
        <div class="shot-actions">
          <button class="btn-row-action btn-row-delete btn-delete-scene" data-scene-id="${scene.id}" title="Excluir Cena Inteira">
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
          </button>
        </div>
      `;

      // Event listener for Scene Heading editing
      const headingInput = sceneRow.querySelector(".scene-heading-content");
      headingInput.onblur = (e) => {
        scene.title = e.target.innerText.toUpperCase();
        e.target.innerText = scene.title; // Force uppercase display
        this.onSaveCallback();
      };
      
      // Auto-uppercase on type
      headingInput.oninput = (e) => {
        // Simple suggestion for scene headings
        const text = e.target.innerText;
        if (text === "i" || text === "I") {
          this.showAutocomplete(e.target, ["INT. ", "INT/EXT. "]);
        } else if (text === "e" || text === "E") {
          this.showAutocomplete(e.target, ["EXT. "]);
        } else {
          this.hideAutocomplete();
        }
      };

      // Delete scene button handler
      sceneRow.querySelector(".btn-delete-scene").onclick = () => {
        if (confirm("Tem certeza que deseja excluir esta cena e todas as suas tomadas?")) {
          this.activeProject.scenes.splice(sceneIdx, 1);
          this.render();
          this.onSaveCallback();
          showToast("Cena excluída!", "success");
        }
      };

      container.appendChild(sceneRow);

      // 2. Render Shots within Scene
      scene.shots.forEach((shot, shotIdx) => {
        const shotRow = document.createElement("div");
        shotRow.className = "shot-row";
        shotRow.setAttribute("draggable", "true");
        shotRow.setAttribute("data-scene-id", scene.id);
        shotRow.setAttribute("data-shot-id", shot.id);

        shotRow.innerHTML = `
          <div class="shot-index" title="Arraste para reordenar">${shot.index}</div>
          <div class="shot-cell shot-video-cell" contenteditable="true" 
               placeholder="Ex: CLOSE-UP - PLONGÉE - ZOOM-IN.\n\nPaulo acorda assustado." 
               data-field="video">${shot.video}</div>
          <div class="shot-cell shot-audio-cell" contenteditable="true" 
               placeholder="Ex: BG: trilha sonora...\n\nPAULO:\nOnde estou?" 
               data-field="audio">${shot.audio}</div>
          <div class="shot-actions no-print">
            <button class="btn-row-action btn-duplicate-row" title="Duplicar Tomada">
              <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
            </button>
            <button class="btn-row-action btn-row-delete btn-delete-row" title="Excluir Tomada">
              <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
            </button>
          </div>
        `;

        // Bind Drag and Drop events to row
        this.bindDragEvents(shotRow);

        // Bind Cell actions & Autocomplete
        const videoCell = shotRow.querySelector(".shot-video-cell");
        const audioCell = shotRow.querySelector(".shot-audio-cell");

        this.bindCellEvents(videoCell, shot, "video");
        this.bindCellEvents(audioCell, shot, "audio");

        // Action Buttons handlers
        shotRow.querySelector(".btn-duplicate-row").onclick = () => {
          this.duplicateShot(scene.id, shot.id);
        };

        shotRow.querySelector(".btn-delete-row").onclick = () => {
          this.deleteShot(scene.id, shot.id);
        };

        container.appendChild(shotRow);
      });
    });

    this.calculateDuration();
  },

  bindCellEvents(cell, shot, field) {
    // Focus tracking
    cell.onfocus = (e) => {
      this.activeCell = e.target;
      // Highlight current row
      document.querySelectorAll(".shot-row").forEach(r => r.classList.remove("active-row"));
      e.target.closest(".shot-row").classList.add("active-row");
    };

    // Save cell on Blur
    cell.onblur = (e) => {
      shot[field] = e.target.innerHTML;
      this.onSaveCallback();
      this.calculateDuration();
    };

    // Live typing helper & Suggestions
    cell.oninput = (e) => {
      shot[field] = e.target.innerHTML;
      this.calculateDuration();
      this.onSaveCallback();

      // Trigger Autocomplete suggestions
      const text = e.target.innerText;
      const caretWord = this.getLastWord(text);

      if (field === "video") {
        // Show camera angle suggestions if typing characters or starting a word
        if (caretWord.length >= 1) {
          const matches = this.videoSuggestions.filter(s => 
            s.startsWith(caretWord.toUpperCase())
          );
          if (matches.length > 0) {
            this.showAutocomplete(e.target, matches);
          } else {
            this.hideAutocomplete();
          }
        } else {
          this.hideAutocomplete();
        }
      } else if (field === "audio") {
        // Suggest Audio tags or Character names
        const audioMatches = this.audioSuggestions.filter(s => 
          s.toUpperCase().startsWith(caretWord.toUpperCase())
        );
        
        // Load dynamic characters
        const charMatches = (this.activeProject.characters || []).filter(c => 
          c.startsWith(caretWord.toUpperCase())
        );

        const allMatches = [...charMatches, ...audioMatches];
        
        if (allMatches.length > 0 && caretWord.length >= 1) {
          this.showAutocomplete(e.target, allMatches);
        } else {
          this.hideAutocomplete();
        }
      }
    };

    // Keydown interceptor: keyboard navigation
    cell.onkeydown = (e) => {
      const autocompleteBox = document.getElementById("autocomplete-box");
      
      // If Autocomplete box is active, redirect Arrow keys and Enter
      if (autocompleteBox.style.display !== "none") {
        const activeItem = autocompleteBox.querySelector(".autocomplete-item.selected");
        const items = Array.from(autocompleteBox.querySelectorAll(".autocomplete-item"));
        
        if (e.key === "ArrowDown") {
          e.preventDefault();
          let nextIdx = 0;
          if (activeItem) {
            const currentIdx = items.indexOf(activeItem);
            nextIdx = (currentIdx + 1) % items.length;
            activeItem.classList.remove("selected");
          }
          items[nextIdx].classList.add("selected");
          return;
        }
        
        if (e.key === "ArrowUp") {
          e.preventDefault();
          let prevIdx = items.length - 1;
          if (activeItem) {
            const currentIdx = items.indexOf(activeItem);
            prevIdx = (currentIdx - 1 + items.length) % items.length;
            activeItem.classList.remove("selected");
          }
          items[prevIdx].classList.add("selected");
          return;
        }

        if (e.key === "Enter") {
          e.preventDefault();
          if (activeItem) {
            activeItem.click();
          } else if (items.length > 0) {
            items[0].click();
          }
          return;
        }

        if (e.key === "Escape") {
          e.preventDefault();
          this.hideAutocomplete();
          return;
        }
      }

      // Enter key default behavior
      if (e.key === "Enter" && !e.shiftKey) {
        // Add new shot row below on Enter in Audio column
        if (field === "audio") {
          e.preventDefault();
          const activeRow = cell.closest(".shot-row");
          const sceneId = activeRow.getAttribute("data-scene-id");
          const shotId = activeRow.getAttribute("data-shot-id");
          
          this.addShotBelow(sceneId, shotId);
          return;
        }
      }

      // Tab key navigation
      if (e.key === "Tab") {
        e.preventDefault();
        const currentRow = cell.closest(".shot-row");
        
        if (field === "video") {
          // Go to Audio
          currentRow.querySelector(".shot-audio-cell").focus();
        } else {
          // Go to next row's Video cell
          const nextRow = currentRow.nextElementSibling;
          if (nextRow && nextRow.classList.contains("shot-row")) {
            nextRow.querySelector(".shot-video-cell").focus();
          } else {
            // If it's a scene heading next, skip it to its first shot
            let nextEl = nextRow;
            while (nextEl && !nextEl.classList.contains("shot-row")) {
              nextEl = nextEl.nextElementSibling;
            }
            if (nextEl) {
              nextEl.querySelector(".shot-video-cell").focus();
            } else {
              // Last row: Auto create a new row!
              const sceneId = currentRow.getAttribute("data-scene-id");
              this.addShot(sceneId);
            }
          }
        }
      }
    };
  },

  // Helper to extract the last word being typed
  getLastWord(text) {
    if (!text) return "";
    const clean = text.replace(/[\n\r]/g, " ");
    const parts = clean.split(" ");
    return parts[parts.length - 1] || "";
  },

  // Auto-complete suggestion floating box
  showAutocomplete(targetCell, items) {
    const box = document.getElementById("autocomplete-box");
    box.innerHTML = "";
    
    items.forEach((item, idx) => {
      const div = document.createElement("div");
      div.className = "autocomplete-item" + (idx === 0 ? " selected" : "");
      div.innerHTML = `
        <span>${item}</span>
        <span class="autocomplete-shortcut">Enter</span>
      `;
      
      div.onclick = (e) => {
        e.stopPropagation();
        this.insertSuggestion(targetCell, item);
      };

      box.appendChild(div);
    });

    // Position box near cursor/cell
    const rect = targetCell.getBoundingClientRect();
    box.style.left = `${rect.left + window.scrollX}px`;
    box.style.top = `${rect.bottom + window.scrollY + 4}px`;
    box.style.display = "block";
  },

  hideAutocomplete() {
    const box = document.getElementById("autocomplete-box");
    box.style.display = "none";
  },

  insertSuggestion(cell, suggestion) {
    const text = cell.innerText;
    const words = text.split(" ");
    words.pop(); // Remove the typed incomplete word
    
    // Add the suggestion
    const preText = words.join(" ");
    const finalVal = (preText ? preText + " " : "") + suggestion;
    
    cell.innerText = finalVal;
    
    // Trigger input update
    const field = cell.getAttribute("data-field");
    const shotRow = cell.closest(".shot-row");
    const sceneId = shotRow.getAttribute("data-scene-id");
    const shotId = shotRow.getAttribute("data-shot-id");
    
    // Update local state model
    const scene = this.activeProject.scenes.find(s => s.id === sceneId);
    if (scene) {
      const shot = scene.shots.find(sh => sh.id === shotId);
      if (shot) {
        shot[field] = cell.innerHTML;
      }
    }

    this.onSaveCallback();
    this.calculateDuration();
    this.hideAutocomplete();
    
    // Refocus cell and place cursor at end
    cell.focus();
    this.moveCaretToEnd(cell);
  },

  // Move cursor to the end of contenteditable element
  moveCaretToEnd(el) {
    const range = document.createRange();
    const sel = window.getSelection();
    range.selectNodeContents(el);
    range.collapse(false);
    sel.removeAllRanges();
    sel.addRange(range);
  },

  // Calculate project estimated duration in seconds
  calculateDuration() {
    let totalSeconds = 0;
    
    if (this.activeProject.scenes) {
      this.activeProject.scenes.forEach((scene) => {
        scene.shots.forEach((shot) => {
          // 1. Get raw text from audio
          const rawAudioText = Exporter.stripHTML(shot.audio);
          
          // 2. Count spoken words (excluding audio cues)
          const wordsCount = this.countSpeechWords(rawAudioText);
          
          // 3. Dialogue duration: ~130 words per minute (2.16 words per second)
          const speakingSec = wordsCount / 2.16;
          
          // 4. Each shot needs a minimum static duration to account for visual actions
          const shotMinSec = 3.0; // 3 seconds baseline
          
          totalSeconds += Math.max(speakingSec, shotMinSec);
        });
      });
    }

    // Round duration
    const roundedSeconds = Math.round(totalSeconds);
    this.activeProject.estimatedDuration = roundedSeconds;

    // Update Topbar indicator
    const indicator = document.getElementById("estimated-duration-val");
    if (indicator) {
      if (roundedSeconds >= 60) {
        const mins = Math.floor(roundedSeconds / 60);
        const secs = roundedSeconds % 60;
        indicator.innerText = `${mins}m ${secs}s`;
      } else {
        indicator.innerText = `${roundedSeconds}s`;
      }
      
      // Visual feedback: pulse red if exceeds target duration!
      const targetDuration = parseInt(document.getElementById("meta-target-duration").value) || 30;
      if (roundedSeconds > targetDuration) {
        indicator.className = "duration-badge highlight-pulse";
        indicator.style.backgroundColor = "hsl(var(--danger-light))";
        indicator.style.color = "hsl(var(--danger))";
      } else {
        indicator.className = "duration-badge";
        indicator.style.backgroundColor = "hsl(var(--accent-light))";
        indicator.style.color = "hsl(var(--accent))";
      }
    }
  },

  countSpeechWords(text) {
    if (!text || text.trim() === "") return 0;
    
    const lines = text.split("\n");
    let speechWords = 0;
    
    lines.forEach((line) => {
      const trimmed = line.trim();
      if (trimmed === "") return;
      
      // Ignore audio markers
      if (trimmed.startsWith("BG:") || 
          trimmed.startsWith("Folley:") || 
          trimmed.startsWith("TRILHA:") || 
          trimmed.startsWith("Loc.")) {
        return;
      }
      
      // Ignore parenthetical markers (e.g. "(rindo)", "(sussurrando)")
      if (trimmed.startsWith("(") && trimmed.endsWith(")")) {
        return;
      }
      
      // Ignore single character name headings in capitals
      if (trimmed === trimmed.toUpperCase() && !trimmed.includes(" ") && trimmed.length > 2) {
        return;
      }

      // Count words in line
      const lineWords = trimmed.split(/\s+/).filter(w => w.length > 0).length;
      speechWords += lineWords;
    });

    return speechWords;
  },

  // DRAG AND DROP REORDERING (HTML5)
  draggedElement: null,

  bindDragEvents(row) {
    row.ondragstart = (e) => {
      this.draggedElement = row;
      row.classList.add("dragging");
      e.dataTransfer.effectAllowed = "move";
      e.dataTransfer.setData("text/plain", row.getAttribute("data-shot-id"));
    };

    row.ondragend = () => {
      row.classList.remove("dragging");
      this.draggedElement = null;
      
      // Re-index all shot indices on end
      this.reindexShots();
    };

    row.ondragover = (e) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = "move";
      
      if (!this.draggedElement || this.draggedElement === row) return;

      const body = document.getElementById("script-grid-body");
      const children = Array.from(body.children);
      const draggedIdx = children.indexOf(this.draggedElement);
      const targetIdx = children.indexOf(row);
      
      // Ensure we are drag-dropping only shots (avoiding dropping onto scene headings)
      if (!row.classList.contains("shot-row")) return;

      if (draggedIdx < targetIdx) {
        body.insertBefore(this.draggedElement, row.nextElementSibling);
      } else {
        body.insertBefore(this.draggedElement, row);
      }
    };
  },

  reindexShots() {
    const body = document.getElementById("script-grid-body");
    const rows = Array.from(body.children);
    
    // Reconstruct the scenes array and indexes
    const newScenes = [];
    let currentScene = null;
    let shotCounter = 1;
    let sceneCounter = 1;

    rows.forEach((element) => {
      if (element.classList.contains("scene-heading-row")) {
        const sceneId = element.querySelector(".scene-heading-content").getAttribute("data-scene-id");
        const title = element.querySelector(".scene-heading-content").innerText;
        
        currentScene = {
          id: sceneId,
          title: title,
          shots: []
        };
        newScenes.push(currentScene);
        shotCounter = 1;
        
        // Update scene heading visual index
        element.querySelector(".scene-heading-index").innerText = `Cena ${String(sceneCounter++).padStart(2, '0')}`;
      } else if (element.classList.contains("shot-row") && currentScene) {
        const shotId = element.getAttribute("data-shot-id");
        const video = element.querySelector(".shot-video-cell").innerHTML;
        const audio = element.querySelector(".shot-audio-cell").innerHTML;
        
        const shotIdxString = `${newScenes.length}-${shotCounter++}`;
        element.querySelector(".shot-index").innerText = shotIdxString;
        
        currentScene.shots.push({
          id: shotId,
          index: shotIdxString,
          video: video,
          audio: audio
        });
      }
    });

    this.activeProject.scenes = newScenes;
    this.onSaveCallback();
    this.calculateDuration();
  },

  // ROWS MANIPULATIONS
  addScene() {
    if (!this.activeProject.scenes) {
      this.activeProject.scenes = [];
    }

    const sceneNum = this.activeProject.scenes.length + 1;
    const newScene = {
      id: "scene_" + Date.now(),
      title: `INT. LOCAÇÃO - DIA`,
      shots: [
        {
          id: "shot_" + Date.now() + "_1",
          index: `${sceneNum}-1`,
          video: "",
          audio: ""
        }
      ]
    };

    this.activeProject.scenes.push(newScene);
    this.render();
    this.onSaveCallback();
    
    // Focus the new scene title
    setTimeout(() => {
      const headings = document.querySelectorAll(".scene-heading-content");
      headings[headings.length - 1].focus();
    }, 100);

    showToast("Nova cena adicionada!", "success");
  },

  addShot(sceneId) {
    const scene = this.activeProject.scenes.find(s => s.id === sceneId);
    if (!scene) return;

    const shotNum = scene.shots.length + 1;
    const sceneIdx = this.activeProject.scenes.indexOf(scene) + 1;
    
    const newShot = {
      id: "shot_" + Date.now(),
      index: `${sceneIdx}-${shotNum}`,
      video: "",
      audio: ""
    };

    scene.shots.push(newShot);
    this.render();
    this.onSaveCallback();

    // Focus the new row's video cell
    setTimeout(() => {
      const rows = document.querySelectorAll(`.shot-row[data-scene-id="${sceneId}"]`);
      rows[rows.length - 1].querySelector(".shot-video-cell").focus();
    }, 100);
  },

  addShotBelow(sceneId, currentShotId) {
    const scene = this.activeProject.scenes.find(s => s.id === sceneId);
    if (!scene) return;

    const currentIdx = scene.shots.findIndex(sh => sh.id === currentShotId);
    if (currentIdx === -1) return;

    const newShot = {
      id: "shot_" + Date.now(),
      index: "", // Will be reindexed instantly
      video: "",
      audio: ""
    };

    // Insert at index + 1
    scene.shots.splice(currentIdx + 1, 0, newShot);
    
    this.render();
    this.onSaveCallback();
    this.reindexShots();

    // Focus video cell of the new row
    setTimeout(() => {
      const rows = Array.from(document.querySelectorAll(`.shot-row[data-scene-id="${sceneId}"]`));
      const targetRow = rows[currentIdx + 1];
      if (targetRow) {
        targetRow.querySelector(".shot-video-cell").focus();
      }
    }, 50);
  },

  duplicateShot(sceneId, shotId) {
    const scene = this.activeProject.scenes.find(s => s.id === sceneId);
    if (!scene) return;

    const shot = scene.shots.find(sh => sh.id === shotId);
    if (!shot) return;

    const duplicate = {
      id: "shot_" + Date.now() + "_" + Math.floor(Math.random() * 100),
      index: "",
      video: shot.video,
      audio: shot.audio
    };

    const idx = scene.shots.indexOf(shot);
    scene.shots.splice(idx + 1, 0, duplicate);
    
    this.render();
    this.onSaveCallback();
    this.reindexShots();
    showToast("Tomada duplicada!", "success");
  },

  deleteShot(sceneId, shotId) {
    const scene = this.activeProject.scenes.find(s => s.id === sceneId);
    if (!scene) return;

    const shotIdx = scene.shots.findIndex(sh => sh.id === shotId);
    if (shotIdx === -1) return;

    scene.shots.splice(shotIdx, 1);

    // If scene is left empty, remove the scene entirely
    if (scene.shots.length === 0) {
      const scIdx = this.activeProject.scenes.indexOf(scene);
      this.activeProject.scenes.splice(scIdx, 1);
    }

    this.render();
    this.onSaveCallback();
    this.reindexShots();
    showToast("Tomada excluída!", "success");
  },

  bindGlobalEvents() {
    // Hide autocomplete box when clicking elsewhere
    window.addEventListener("click", () => {
      this.hideAutocomplete();
    });
  }
};
