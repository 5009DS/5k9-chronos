// --- Story & 3-Act Screenplay Controller ---

const ScreenplayController = {
  activeProject: null,
  onSaveCallback: null,

  init(project, onSave) {
    this.activeProject = project;
    this.onSaveCallback = onSave;

    // Set textareas content
    document.getElementById("act1-setup").value = project.acts.setup || "";
    document.getElementById("act2-confront").value = project.acts.confront || "";
    document.getElementById("act3-resolve").value = project.acts.resolve || "";
    
    document.getElementById("screenplay-concept").value = project.concept || "";
    document.getElementById("screenplay-tone").value = project.tone || "";

    // Load initial character list
    this.renderCharacters();
    this.updateCharCounts();

    // Bind event listeners
    this.bindEvents();
  },

  bindEvents() {
    // Save on key inputs
    const textareas = [
      { id: "act1-setup", key: "setup", parent: "acts" },
      { id: "act2-confront", key: "confront", parent: "acts" },
      { id: "act3-resolve", key: "resolve", parent: "acts" },
      { id: "screenplay-concept", key: "concept", parent: null },
      { id: "screenplay-tone", key: "tone", parent: null }
    ];

    textareas.forEach(({ id, key, parent }) => {
      const el = document.getElementById(id);
      
      // Remove previous listener to avoid duplicates
      el.oninput = null;
      
      el.oninput = (e) => {
        const val = e.target.value;
        if (parent === "acts") {
          this.activeProject.acts[key] = val;
        } else {
          this.activeProject[key] = val;
        }
        
        this.updateCharCounts();
        this.onSaveCallback();
      };
    });

    // Character Addition
    const addCharBtn = document.getElementById("btn-add-character");
    addCharBtn.onclick = () => {
      const charName = prompt("Digite o nome do personagem (será convertido para MAIÚSCULO):");
      if (charName && charName.trim() !== "") {
        this.addCharacter(charName.trim().toUpperCase());
      }
    };
  },

  updateCharCounts() {
    const actIds = ["act1-setup", "act2-confront", "act3-resolve"];
    actIds.forEach(id => {
      const val = document.getElementById(id).value;
      const countLabel = document.getElementById(id).parentElement.nextElementSibling.querySelector(".char-count");
      if (countLabel) {
        countLabel.innerText = `${val.length} caracteres`;
      }
    });
  },

  renderCharacters() {
    const container = document.getElementById("character-tags-container");
    container.innerHTML = "";

    if (!this.activeProject.characters || this.activeProject.characters.length === 0) {
      container.innerHTML = `<span class="section-tip" style="margin-bottom:0; font-style:italic;">Nenhum personagem cadastrado.</span>`;
      return;
    }

    this.activeProject.characters.forEach((char) => {
      const tag = document.createElement("div");
      tag.className = "character-tag";
      tag.innerHTML = `
        <span>${char}</span>
        <button class="btn-remove-tag" data-char="${char}">
          <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>
      `;

      tag.querySelector(".btn-remove-tag").onclick = (e) => {
        const charToRemove = e.currentTarget.getAttribute("data-char");
        this.removeCharacter(charToRemove);
      };

      container.appendChild(tag);
    });
  },

  addCharacter(char) {
    if (!this.activeProject.characters) {
      this.activeProject.characters = [];
    }

    // Standardize input
    const cleanName = char.replace(/[^A-Z0-9À-ÿ\s-]/gi, "").trim().toUpperCase();
    if (!cleanName) return;

    if (this.activeProject.characters.includes(cleanName)) {
      showToast("Este personagem já está cadastrado!", "error");
      return;
    }

    this.activeProject.characters.push(cleanName);
    this.renderCharacters();
    this.onSaveCallback();
    showToast(`Personagem ${cleanName} adicionado!`, "success");
  },

  removeCharacter(char) {
    const index = this.activeProject.characters.indexOf(char);
    if (index > -1) {
      this.activeProject.characters.splice(index, 1);
      this.renderCharacters();
      this.onSaveCallback();
    }
  }
};
